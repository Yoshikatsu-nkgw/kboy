package com.example.kboy_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
